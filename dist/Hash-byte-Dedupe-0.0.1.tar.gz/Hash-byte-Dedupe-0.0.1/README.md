# Hash-byte-Dedupe
## A simple project that uses matching hash to find exact maches of files.
